from flask import Flask, render_template, request,redirect
from langchain.document_loaders import HuggingFaceDatasetLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from transformers import AutoTokenizer, AutoModelForQuestionAnswering
from langchain import HuggingFacePipeline
from langchain.chains import RetrievalQA
from flask import Flask, render_template, request
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from flask import Flask, render_template, request

app = Flask(__name__)

# Load the trained model
model = joblib.load('trained_model.pkl')

# Load the TF-IDF vectorizer
tfidf_vectorizer = joblib.load('tfidf_vectorizer.pkl')

# Define the path to the pre-trained model you want to use
modelPath = "sentence-transformers/all-MiniLM-l6-v2"

# Create a dictionary with model configuration options, specifying to use the CPU for computations
model_kwargs = {'device': 'cpu'}

# Create a dictionary with encoding options, specifically setting 'normalize_embeddings' to False
encode_kwargs = {'normalize_embeddings': False}

# Initialize an instance of HuggingFaceEmbeddings with the specified parameters
embeddings = HuggingFaceEmbeddings(
    model_name=modelPath,     # Provide the pre-trained model's path
    model_kwargs=model_kwargs, # Pass the model configuration options
    encode_kwargs=encode_kwargs # Pass the encoding options
)

# Load your FAISS index (replace "faiss_index" with your actual index name)
new_db = FAISS.load_local("faiss_index", embeddings)

@app.route('/')
def index():
    return render_template('index.html')

# Define the prediction route
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        case_description = request.form['case_description']
        # Vectorize the input text using the loaded TF-IDF vectorizer
        transformed_input = tfidf_vectorizer.transform([case_description])
        prediction = model.predict(transformed_input)
        return render_template('result.html', prediction=prediction[0])

@app.route('/search', methods=['POST'])
def search():
    query = request.form['query']
    docs = new_db.similarity_search(query)
    result = docs[0].page_content if docs else "No matching documents found."
    return render_template('legal_case.html', query=query, result=result)

@app.route('/lawgpt')
def lawgpt():
    # Redirect to the legal_case.html page
    return redirect('/legal_case')

# Define the route for the legal_case.html page
@app.route('/legal_case')
def legal_case():
    # Render the legal_case.html template
    return render_template('legal_case.html')

if __name__ == '__main__':
    app.run(debug=True)
